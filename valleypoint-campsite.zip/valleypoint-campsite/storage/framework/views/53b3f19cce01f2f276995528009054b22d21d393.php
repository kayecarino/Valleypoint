<?php $__env->startSection('content'); ?>
<div class="col-md-12 text-center lodging-tabs mx-1">
    <nav class="nav nav-pills centered-pills">
        <a class="nav-item nav-link active" style="background-color:#060f0ed4;" href="/glamping">Physical View</a>
        <a class="nav-item nav-link" style="color:#505050" href="/calendar-glamping">Calendar View</a>
    </nav>
</div>
<div class="container-fluid col-md-9 mx-1 pb-5 pt-1">
    <div class="row">
            
            <div class="container lodging-tabs">
                <ul class="nav nav-tabs pt-0" style="width:93%">
                    <li class="nav-item">
                        <a class="nav-link active" href="/glamping/">Glamping</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:#505050;" href="/backpacker">Backpacker</a>
                    </li>
                </ul>
            </div>
            <?php if(count($units) > 0): ?>
            <div class="container" style="padding-top:1em;">
                <div class="container scrollbar-near-moon pb-4" style="position:fixed; max-height:68.5vh; max-width:55%; overflow-y:auto;">
                    <div class="row">  

                <?php                    
                    $unitArray = array(); 
                    array_push($unitArray, 0);   
                ?>

                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($unit->unitType == 'tent'): ?>   
                        <?php if($unit->status == 'ongoing'): ?>
                        <a data-toggle="modal" data-target="#view-details" style="cursor:pointer" class="load-glamping-details" id=<?php echo e($unit->unitID); ?>>       
                        <div class="card mx-2" style="width:16rem; height:7.5em; background-image:url(<?php echo e(asset('tent.png')); ?>); background-size:cover; background-repeat:no-repeat;">
                            <div class="card-body">
                            <h5 class="card-title">
                                <?php echo e($unit->unitNumber); ?>

                                <?php
                                    $withPendingCharges = false;
                                ?>
                                <?php $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($charge->accommodationID == $unit->accommodationID): ?>
                                        <?php if($charge->balance > 0): ?>
                                            <?php
                                                $withPendingCharges = true;
                                            ?> 
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($withPendingCharges == true): ?>
                                <span class="badge badge-info float-right" style="font-size:.55em; width:5em;">Pending</span>   
                                <?php else: ?>
                                <span class="badge badge-success float-right" style="font-size:.55em; width:5em;">Paid</span>  
                                <?php endif; ?>
                            </h5>

                            <?php
                                $today = \Carbon\Carbon::today();
                                $currentDate = \Carbon\Carbon::parse($today)->format('Y-m-d');
                            ?>

                            <?php if((\Carbon\Carbon::parse($unit->checkoutDatetime)->format('Y-m-d') == $currentDate)): ?>
                                <p class="card-text"><?php echo e($unit->firstName); ?> <?php echo e($unit->lastName); ?></p>
                                <p class="card-text" style="color:#fdc000; font-style:italic;">Checks-out today!</p>
                            <?php elseif((\Carbon\Carbon::parse($unit->checkoutDatetime)->format('Y-m-d') < $currentDate)): ?>
                                <p class="card-text"><?php echo e($unit->firstName); ?> <?php echo e($unit->lastName); ?></p>
                                <p class="card-text" style="color:red; font-style:italic;">Overdue!</p>
                            <?php else: ?>
                                <p class="card-text"><?php echo e($unit->firstName); ?> <?php echo e($unit->lastName); ?></p>
                                <p class="card-text" style="color:green; font-style:italic;"> <?php echo e($unit->serviceName); ?></p>
                            <?php endif; ?>

                        <?php else: ?>
                            <a data-toggle="modal" data-target="#checkin-reserve" style="cursor:pointer; text-decoration:none !important;" class="load-glamping-available-unit" id=<?php echo e($unit->unitID); ?>>       
                            <div class="card mx-2" style="width:16rem; height:7.5em; background-image:url(<?php echo e(asset('tent-empty.png')); ?>); background-size:cover; background-repeat:no-repeat;">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo e($unit->unitNumber); ?>

                                        
                                    </h5>
                            <?php
                                $reservationCount = 0; 
                                $today = \Carbon\Carbon::today();
                                $currentDate = \Carbon\Carbon::parse($today)->format('Y-m-d');
                            ?>

                            <?php if(count($reservations) > 0): ?> 
                                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(($reservation->id == $unit->unitID) && (\Carbon\Carbon::parse($reservation->checkinDatetime)->format('Y-m-d') == $currentDate)): ?>
                                        <?php if(array_search($unit->unitID, $unitArray) == false): ?>
                                        <p class="card-text"><?php echo e($reservation->firstName); ?> <?php echo e($reservation->lastName); ?></p>
                                        <p class="card-text" style="color:lightseagreen; font-style:italic;">Checks-in today!</p>
                                        <?php
                                            array_push($unitArray, $unit->unitID);
                                        ?>
                                        <?php endif; ?>
                                    <?php elseif($reservation->id == $unit->unitID): ?>
                                        <?php if(array_search($unit->unitID, $unitArray) == false): ?>
                                            <?php if(\Carbon\Carbon::parse($reservation->checkinDatetime)->format('Y-m-d') < $currentDate): ?>
                                            <p class="card-text"><?php echo e($reservation->firstName); ?> <?php echo e($reservation->lastName); ?></p>
                                            <p class="card-text" style="color:red; font-style:italic;">
                                                Update reservation!
                                                
                                            </p>
                                            <?php else: ?>
                                            <p class="card-text" style="color:lightseagreen; font-style:italic;">
                                                Next checkin:<br>
                                                <?php echo e(\Carbon\Carbon::parse($reservation->checkinDatetime)->format('F j, Y')); ?>

                                            </p>
                                            <?php endif; ?>
                                        <?php
                                            array_push($unitArray, $unit->unitID);
                                        ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                        <div class="container" style="padding-top:1em; padding-left:2em;">
                            <p>No units found</p>
                        </div>
            <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid col-md-3 m-0 p-0" id="unitFinder" style="padding-top:25em;">
            <div class="card p-0 mx-0" style="font-size:0.9em; ">
                <div class="card-body">
                    <h4 class="text-center pb-1">Tent Finder</h4>
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group row">
                            <label class="col-sm-4 mb-0 mt-2" for="checkin" style="padding-right:0;">Check-in date</label>
                            <div class="input-group input-group-sm mb-1 col-sm-8">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input class="form-control finderInputs" id="finderCheckinDate" type="date" name="checkin" maxlength="15" placeholder="" value="" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 mb-0 mt-2" for="checkout" style="padding-right:0;">Check-out date</label>
                            <div class="input-group input-group-sm mb-1 col-sm-8">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input class="form-control finderInputs" type="date" id="finderCheckoutDate" name="checkout" maxlength="15" placeholder="" value="" required>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <label class="col-sm-4 mb-0 mt-2" for="unitCount">No. of tents</label>
                            <div class="input-group input-group-sm mb-1 col-sm-8">
                                <input class="form-control finderInputs" type="number" id="finderUnitCount" name="unitCount" maxlength="15" placeholder="" value="" required>
                            </div>
                        </div>
                        <hr class="my-3">
                        <h6 class="text-center mb-1">Available Tents</h6>
                        <div class="card p-0 mx-0 scrollbar-near-moon" style="font-size:0.9em; min-height:33vh; max-height:20vh; overflow-y:auto;">
                            <div class="card-body pb-0" id="availableUnitsContainer" style="display:block;">
                                <div class="available-units-list" id="divAvailableUnitsList" style="font-size:1.1em">
                                     
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="checkedUnits" name="checkedUnits" value="hello">
                        
                        <div class="row pt-2">
                            <div class="col-md-6">
                                <button type="submit" formaction="reserve-glamping-finder" class="btn btn-block btn-primary" id="finderReserve" style="float:left;" disabled>Add Reservation</button>
                            </div>
                            <div class="col-md-6">
                                <button type="submit" formaction="checkin-glamping-finder" class="btn btn-block btn-secondary" id="finderCheckin" style="float:right;" disabled>Checkin</button>
                            </div>
                        </div>
                    <form>
                </div>
            </div>
        </div>
    </div>

    <!-- Details Modal -->
    <div class="modal fade right" id="view-details" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-full-height modal-right modal-notify modal-info" role="document">
            <div class="modal-content">
                <!--Header-->
                <div class="modal-header">
                    <h4 id="modal-head1"><h4>
                    <!--p class="heading lead">Tent 1</p-->
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="white-text">×</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body scrollbar-near-moon-wide" id="modal-body">
                </div>
                <!--Footer-->
                <div class="modal-footer justify-content-right">
                    <a href="" id="reserve">
                        <button type="button" class="btn btn-success">Add Reservation</button>
                    </a>
                    <!--a href="" id="editDetails">
                        <button type="button" class="btn btn-info">View Details</button>
                    </a>
                    <a href="" id="checkout">
                        <button type="button" class="btn btn-danger">Check-out</button>
                    </a-->
                </div>
            </div>
        </div>
    </div>

    <!-- Check-in or reserve modal -->
    <div class="modal fade right" id="checkin-reserve" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-full-height modal-right modal-notify modal-info" role="document">
            <div class="modal-content">
                <!--Header-->
                <div class="modal-header">
                    <h4 id="modal-head2"><h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="white-text">×</span>
                    </button>
                </div>
                <!--Body-->
                <div class="modal-body scrollbar-near-moon-wide" id="modal-body-empty">
                    <!--div class="col-md-12">
                        <h5 class="text-center mb-4">Choose action:</h5>
                    </div-->
                </div>
                <!--Footer-->
                <div class="modal-footer justify-content-right">
                    <a href="" id="checkinMain">
                        <button type="button" class="btn btn-primary">Check-in</button>
                    </a>
                    <a href="" id="reserveEmpty">
                        <button type="button" class="btn btn-secondary">Add reservation</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>