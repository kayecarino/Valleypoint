<?php $__env->startSection('content'); ?>
<div class="container pb-5">
    <div class="pt-3 pb-3">
    
        <h3 class="text-center">Orders</h3>
    </div>
    <div class="col-md-12">
        <table id="ordersTable" data-order='[[ 0, "asc" ]]' class="table table-sm dataTable stripe compact" cellspacing="0">
              <thead>
                <tr class="">
                  <th>Order ID</th>
                  <th>Table Number</th>
                  <th>Orders</th>
                  <th>Order Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                
                <?php if(count($orders) > 1): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                  <td><?php echo e($order->orderID); ?></td>
                  <td><?php echo e($order->tableNumber); ?></td>
                  <td><?php echo e($order->productName); ?></td>
                  <td><?php echo e($order->status); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($order->orderDatetime)->format('M j, Y')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
          </table>
        </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>