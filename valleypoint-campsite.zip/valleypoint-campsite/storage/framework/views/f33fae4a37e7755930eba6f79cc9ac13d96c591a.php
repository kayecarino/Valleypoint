<?php $__env->startSection('content'); ?>
<?php if(isset($unit)): ?>
<?php if(count($unit) > 0): ?>
    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container pb-5">
        <div class="pt-3 pb-3 text-center">
            <a href="<?php echo e(URL::previous()); ?>">
                <span style="float:left;">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>
                    <strong>Back</strong>
                </span>
            </a>
            <h3>Check-in Form</h3>
        </div>   
        <form method="POST" action="/checkin-glamping">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="selectedUnit" id="selectedUnit" value="<?php echo e($unit->unitNumber); ?>">
        <div class="row">
            <div class="col-md-4 order-md-2 mb-4 mx-0">
                <div class="card p-0 mx-0">
                    <h4 class="text-muted" style="text-align:center; padding:0.5em;">Charges</h4>
                    <table class="table table-striped" style="font-size:.88em;">
                        <thead>
                            <tr>
                                <th scope="col" style="width:40%">Description</th>
                                <th scope="col">Qty.</th>
                                <th scope="col">Price</th>
                                <th scope="col">Total</th>
                            </tr>
                        </thead>
                        <tbody id="invoiceRows">
                            <tr id="invoiceUnit<?php echo e($unit->unitNumber); ?>">
                                <td style="display:none;"><input id="invoiceCheckBox<?php echo e($unit->unitNumber); ?>" class="form-check-input invoiceCheckboxes" type="checkbox" checked></td>
                                <td id="invoiceDescription<?php echo e($unit->unitNumber); ?>" class="invoiceDescriptions">Glamping Solo</td>
                                <td id="invoiceQuantity<?php echo e($unit->unitNumber); ?>" style="text-align:right;" class="invoiceQuantities">1x1</td>
                                <td id="invoiceUnitPrice<?php echo e($unit->unitNumber); ?>" style="text-align:right;" class="invoiceUnitPrices">1350.00</td>
                                <td id="invoiceTotalPrice<?php echo e($unit->unitNumber); ?>" style="text-align:right;" class="invoicePrices">1350.00</td>
                            </tr>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="3" scope="row">TOTAL:</th>
                                <th id="invoiceGrandTotal" style="text-align:right;"></th>
                            </tr>                            
                            <tr id="rowAmountPaid" style="display:none">
                                <th colspan="3" scope="row">AMOUNT PAID:</th>
                                <th id="invoiceAmountPaid" style="text-align:right;"></th>
                            </tr>   
                            <tr>
                                <td colspan="4"><button type="button" class="btn btn-primary btn-block w-100" style="text-align:center;width:8em" id="proceedToPayment" data-toggle="modal" data-target="#chargesModal">
                                    Get payment
                                </button></td>
                            </tr>
                            
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="col-md-8 order-md-1 check-in-form">
                <h5 style="margin-bottom:.80em;">Guest Details</h5>
                    <div class="form-group row">
                        <div class="col-md-4 mb-1">
                            <label for="firstName">First name <strong style="color:red"><em>*</em></strong></label>
                            <input class="form-control" type="text" name="firstName" required="required" maxlength="15" id = "firstName" placeholder="" value="" autocomplete = "off">

                        </div>                  
                      
                        
                        <div class="col-md-5 mb-1">
                            <label for="lastName">Last name <strong style="color:red"><em>*</em></strong></label>
                            <input class="form-control" type="text" name="lastName" r equired="required" maxlength="20" id = "lastName" placeholder="" value="" autocomplete = "off">
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="unitNumberOfPax">No. of pax <strong style="color:red"><em>*</em></strong></label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-users" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input class="form-control numberOfPaxGlamping"  required="required" min="1" max="100" name="numberOfPaxGlamping" type="number" placeholder="1" value="">
                            </div>
                        </div>
                    </div>  
                    <div class="form-group row">
                        <div class="col-md-6 mb-1">
                            <label for="contactNumber">Contact number <strong style="color:red"><em>*</em></strong></label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input class="form-control" type="text" name="contactNumber"  id ="contactNumber" required="required" maxlength="11" placeholder="" value="" autocomplete = "off">
                            </div>
                        </div>
                        <div class="col-md-6 mb-1">
                            <label for="glamping">Accommodation</label>
                            <div class="input-group">
                                <input class="form-control" type="text" name="glamping" maxlength="11" placeholder="" value="Glamping" disabled>
                            </div>
                        </div>
                    </div>  
                    <hr class="mb-4">
                    <h5 style="margin-bottom:.80em;">Unit Details</h5>
                    <div class="form-group row">
                        <div class="col-md-2 mb-1">
                            <label for="unitID">No. of tents</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-campground" aria-hidden="true"></i>
                                    </span>
                                </div>
                            <input class="form-control" type="number" id="numberOfUnits" name="numberOfUnits" required placeholder="" value="1" min="1" max="80" readonly>
                            </div>
                        </div>
                        <?php
                            //$source = implode(',', array($unitSource->unitNumber));
                            $source = array();
                            foreach($unitSource as $unitSource) {
                                array_push($source, $unitSource->unitNumber);
                            }

                            $source = implode(',', $source);
                        ?>
                        <div class="col-md-10 mb-1">
                            <label for="unitNumber">Unit/s</label>
                            <input type="text" name="unitID" required="required" class="form-control" style="display:none;position:absolute;" value="<?php echo e($unit->id); ?>">
                            <input class="form-control" type="text" name="unitNumber" required id="tokenfield" value="<?php echo e($unit->unitNumber); ?>" required>
                            <input type="hidden" id="unitSource" value="<?php echo e($source); ?>">
                            <input class="form-control" style="display:none;float:left;" type="text" name="unitID" value="<?php echo e($unit->id); ?>">
                            
                            <!-- relocated    div id="alertContainer" class="alert alert-danger mt-2" style="display:none;">
                                <a href="#" class="close">&times;</a>
                                <span id="alertMessage"><strong>Occupied!</strong> Tent 3 is occupied from March 25 to March 27.</span>
                            </div-->
                        </div>
                    </div>
                    
                    <?php                        
                        $stayDuration = 1;

                        $unitTotalPrice = 1350 * $stayDuration;
                    ?>
                    <div class="form-group row" id="divUnits">
                        <div class="col-md-2 mb-1" id="divUnitNumber<?php echo e($unit->unitNumber); ?>">
                            <label for="unitNumber">Unit number</label>
                            <input type="text" class="form-control" value="<?php echo e($unit->unitNumber); ?>" disabled>
                            <input class="" name="totalPrice<?php echo e($unit->unitNumber); ?>" id="totalPrice<?php echo e($unit->unitNumber); ?>" type="number" style="display:none;position:absolute" value="<?php echo e($unitTotalPrice); ?>">
                        </div>
                        <div class="col-md-2 mb-1" id="divAccommodationPackage<?php echo e($unit->unitNumber); ?>">
                            <label for="additionalServiceUnitPrice">Package</label>
                            <select class="form-control accommodationPackages" name="accommodationPackage<?php echo e($unit->unitNumber); ?>" id="accommodationPackage<?php echo e($unit->unitNumber); ?>">
                                <option value="1">Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4">4 pax</option>
                            </select>
                        </div>

                        <div class="col-md-4 mb-1" id="divCheckinDate<?php echo e($unit->unitNumber); ?>">
                            <label for="checkinDate">Check-in date</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input type="date" name="checkinDate<?php echo e($unit->unitNumber); ?>" required="required" class="form-control checkinDates" id="checkinDate<?php echo e($unit->unitNumber); ?>" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                            </div>
                        </div>

                        <div class="col-md-4 mb-1" id="divCheckoutDate<?php echo e($unit->unitNumber); ?>">
                            <label for="checkoutDate">Check-out date <strong style="color:red"><em>*</em></strong></label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input type="date" name="checkoutDate<?php echo e($unit->unitNumber); ?>" required="required" class="form-control checkoutDates" id="checkoutDate<?php echo e($unit->unitNumber); ?>" value="">
                                
                            </div>
                        </div>
                    </div>                     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    <?php endif; ?>
<?php else: ?>
<div class="container pb-5">
    <div class="pt-3 pb-3 text-center">
        <a href="<?php echo e(URL::previous()); ?>">
            <span style="float:left;">
                <i class="fa fa-chevron-left" aria-hidden="true"></i>
                <strong>Back</strong>
            </span>
        </a>
        <h3>Check-in Form</h3>
    </div>   
    <form method="POST" action="/checkin-glamping">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
    <input type="hidden" name="selectedUnit" id="selectedUnit" value="">
    <div class="row">
        <div class="col-md-4 order-md-2 mb-4 mx-0">
            <div class="card p-0 mx-0">
                <h4 class="text-muted" style="text-align:center; padding:0.5em;">Charges</h4>
                <table class="table table-striped" style="font-size:.88em;">
                    <thead>
                        <tr>
                            <th scope="col" style="width:40%">Description</th>
                            <th scope="col">Qty.</th>
                            <th scope="col">Price</th>
                            <th scope="col">Total</th>
                        </tr>
                    </thead>
                    <tbody id="invoiceRows">
                        <?php if(count($charges) > 0): ?>
                        <?php
                           $totalPrice = 0; 
                        ?>
                        <?php $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $checkin = new DateTime($givenCheckinDate);
                            $checkout = new DateTime($givenCheckoutDate);
                            $stayDuration = date_diff($checkin, $checkout)->days;

                            $invoicePrice = 1350 * $stayDuration;

                            $totalPrice += $invoicePrice;
                        ?>
                        <tr id="invoiceUnit<?php echo e($charge->unitNumber); ?>">
                            <td style="display:none;"><input id="invoiceCheckBox<?php echo e($charge->unitNumber); ?>" class="form-check-input invoiceCheckboxes" type="checkbox" checked></td>
                            <td id="invoiceDescription<?php echo e($charge->unitNumber); ?>" class="invoiceDescriptions">Glamping Solo</td>
                            <td id="invoiceQuantity<?php echo e($charge->unitNumber); ?>" style="text-align:right;" class="invoiceQuantities">1x<?php echo e($stayDuration); ?></td>
                            <td id="invoiceUnitPrice<?php echo e($charge->unitNumber); ?>" style="text-align:right;" class="invoiceUnitPrices">1350.00</td>
                            <td id="invoiceTotalPrice<?php echo e($charge->unitNumber); ?>" style="text-align:right;" class="invoicePrices"><?php echo e(number_format((float)($invoicePrice), 2, '.', '')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th colspan="3" scope="row">TOTAL:</th>
                            <th id="invoiceGrandTotal" style="text-align:right;"><?php echo e(number_format((float)($totalPrice), 2, '.', '')); ?></th>
                        </tr>                        
                        <tr id="rowAmountPaid" style="display:none">
                            <th colspan="3" scope="row">AMOUNT PAID:</th>
                            <th id="invoiceAmountPaid" style="text-align:right;"></th>
                        </tr>   
                        <tr>
                            <td colspan="4"><button type="button" class="btn btn-primary btn-block w-100" style="text-align:center;width:8em" id="proceedToPayment" data-toggle="modal" data-target="#chargesModal">
                                Get payment
                            </button></td>
                        </tr>
                        
                    </tfoot>
                </table>
            </div>
        </div>
        <div class="col-md-8 order-md-1 check-in-form">
            <h5 style="margin-bottom:.80em;">Guest Details</h5>
                <div class="form-group row">
                    <div class="col-md-4 mb-1">
                        <label for="firstName">First name</label>
                        <input class="form-control" type="text" name="firstName" id="firstName" required="required" maxlength="15" placeholder="" value="">
                    </div>
                    <div class="col-md-5 mb-1">
                        <label for="lastName">Last name</label>
                        <input class="form-control" type="text" name="lastName" id="lastName" required="required" maxlength="20" placeholder="" value="">
                    </div>
                    <div class="col-md-3 mb-1">
                        <label for="unitNumberOfPax">No. of pax</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-users" aria-hidden="true"></i>
                                </span>
                            </div>
                            <input class="form-control numberOfPaxGlamping"  required="required" min="1" max="100" name="numberOfPaxGlamping" type="number" placeholder="" value="">
                        </div>
                    </div>
                </div>  
                <div class="form-group row">
                    <div class="col-md-6 mb-1">
                        <label for="contactNumber">Contact number</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </span>
                            </div>
                            <input class="form-control" type="text" name="contactNumber"  required="required" maxlength="11" placeholder="" value="">
                        </div>
                    </div>
                    <div class="col-md-6 mb-1">
                        <label for="glamping">Accommodation</label>
                        <div class="input-group">
                            <input class="form-control" type="text" name="glamping" maxlength="11" placeholder="" value="Glamping" disabled>
                        </div>
                    </div>
                </div>  
                <hr class="mb-4">
                <h5 style="margin-bottom:.80em;">Unit Details</h5>
                <div class="form-group row">
                    <div class="col-md-2 mb-1">
                        <label for="unitID">No. of tents</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fa fa-campground" aria-hidden="true"></i>
                                </span>
                            </div>
                        <input class="form-control" type="number" id="numberOfUnits" name="numberOfUnits" required placeholder="" value="<?php echo e(count($unitNumber)); ?>" min="1" max="80" readonly>
                        </div>
                    </div>                    
                    <?php
                        //$source = implode(',', array($unitSource->unitNumber));
                        $source = array();
                        foreach($unitSource as $unitSource) {
                            array_push($source, $unitSource->unitNumber);
                        }

                        $source = implode(',', $source);
                    ?>
                    <?php if(count($unitNumber) > 0): ?>
                    <?php
                        $unitNumbers = "";
                    ?>
                    <?php $__currentLoopData = $unitNumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if($loop->iteration == count($unitNumber)){
                            $unitNumbers .= $unitNum." ";
                        } else {
                            $unitNumbers .= $unitNum.", ";
                        }
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="col-md-10 mb-1">
                        <label for="unitNumber">Unit/s</label>
                        
                        <input class="form-control" type="text" name="unitNumber" required id="tokenfield" value="<?php echo e($unitNumbers); ?>" required>
                        <input type="hidden" id="unitSource" value="<?php echo e($source); ?>">
                    </div>
                </div>
                <div class="form-group row" id="divUnits">
                    <?php if(count($units) > 0): ?>
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php                        
                        $checkin = new DateTime($givenCheckinDate);
                        $checkout = new DateTime($givenCheckoutDate);
                        $stayDuration = date_diff($checkin, $checkout)->days;

                        $unitTotalPrice = 1350 * $stayDuration;
                    ?>
                    <?php if($loop->iteration == 1): ?>
                    <div class="col-md-2 mb-1" id="divUnitNumber<?php echo e($unit->unitNumber); ?>">
                        <label for="unitNumber">Unit number</label>
                        <input type="text" class="form-control" value="<?php echo e($unit->unitNumber); ?>" disabled>
                        <input class="" name="totalPrice<?php echo e($unit->unitNumber); ?>" id="totalPrice<?php echo e($unit->unitNumber); ?>" type="number" style="display:none;position:absolute" value="<?php echo e($unitTotalPrice); ?>">
                    </div>
                    <div class="col-md-2 mb-1" id="divAccommodationPackage<?php echo e($unit->unitNumber); ?>">
                        <label for="additionalServiceUnitPrice">Package</label>
                        <select class="form-control accommodationPackages" name="accommodationPackage<?php echo e($unit->unitNumber); ?>" id="accommodationPackage<?php echo e($unit->unitNumber); ?>">
                            <option value="1">Solo</option>
                            <option value="2">2 Pax</option>
                            <option value="3">3 pax</option>
                            <option value="4">4 pax</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-1" id="divCheckinDate<?php echo e($unit->unitNumber); ?>">
                        <label for="checkinDate">Check-in date</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                </span>
                            </div>
                            <input type="date" name="checkinDate<?php echo e($unit->unitNumber); ?>" required="required" class="form-control checkinDates" id="checkinDate<?php echo e($unit->unitNumber); ?>" value="<?php echo e($givenCheckinDate); ?>">
                        </div>
                    </div>

                    <div class="col-md-4 mb-1" id="divCheckoutDate<?php echo e($unit->unitNumber); ?>">
                        <label for="checkoutDate">Check-out date</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                </span>
                            </div>
                            <input type="date" name="checkoutDate<?php echo e($unit->unitNumber); ?>" required="required" class="form-control checkoutDates" id="checkoutDate<?php echo e($unit->unitNumber); ?>" value="<?php echo e($givenCheckoutDate); ?>">
                            
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="col-md-2 mb-1" id="divUnitNumber<?php echo e($unit->unitNumber); ?>">
                        <input type="text" class="form-control" value="<?php echo e($unit->unitNumber); ?>" disabled>
                        <input class="" name="totalPrice<?php echo e($unit->unitNumber); ?>" id="totalPrice<?php echo e($unit->unitNumber); ?>" type="number" style="display:none;position:absolute" value="<?php echo e($unitTotalPrice); ?>">
                    </div>
                    <div class="col-md-2 mb-1" id="divAccommodationPackage<?php echo e($unit->unitNumber); ?>">
                        <select class="form-control accommodationPackages" name="accommodationPackage<?php echo e($unit->unitNumber); ?>" id="accommodationPackage<?php echo e($unit->unitNumber); ?>">
                            <option value="1">Solo</option>
                            <option value="2">2 Pax</option>
                            <option value="3">3 pax</option>
                            <option value="4">4 pax</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-1" id="divCheckinDate<?php echo e($unit->unitNumber); ?>">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                </span>
                            </div>
                            <input type="date" name="checkinDate<?php echo e($unit->unitNumber); ?>" required="required" class="form-control checkinDates" id="checkinDate<?php echo e($unit->unitNumber); ?>" value="<?php echo e($givenCheckinDate); ?>">
                        </div>
                    </div>

                    <div class="col-md-4 mb-1" id="divCheckoutDate<?php echo e($unit->unitNumber); ?>">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                </span>
                            </div>
                            <input type="date" name="checkoutDate<?php echo e($unit->unitNumber); ?>" required="required" class="form-control checkoutDates" id="checkoutDate<?php echo e($unit->unitNumber); ?>" value="<?php echo e($givenCheckoutDate); ?>">
                            
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
<?php endif; ?>
                <div id="dateGapContainer" class="alert alert-warning mt-2" style="display:none;">
                    <a href="#" class="close">&times;</a>
                    <span id="dateGapMessage"><strong>Invalid Dates!</strong> Accommodation dates must be consecutive.</span>
                </div>
                
                <div id="dateAlertContainer" class="alert alert-warning mt-2" style="display:none;">
                    <a href="#" class="close">&times;</a>
                    <span id="dateAlertMessage"><strong>Invalid Date!</strong> Please select a check-out date after the check-in date.</span>
                </div>

                <div id="alertContainer" class="alert alert-danger mt-2" style="display:none;">
                    <a href="#" class="close">&times;</a>
                    <span id="alertMessage"><strong>Occupied!</strong> Tent 3 is occupied from March 25 to March 27.</span>
                </div>
                
                <hr class="mb-4">
                <div class="form-group row pb-3" id="divAdditionalServices">
                    <div class="col-md-12 mb-1">
                        <h5 style="margin-bottom:.80em;">Additional Services</h5>
                    </div>
                    <input type="hidden" >
                    <div class="col-md-3 mb-1" id="divServiceName">
                        <label for="additionalServiceName">Service name</label>
                        <select name="additionalServiceName" id="serviceSelect" class="form-control serviceSelect" >
                            <option value="choose" selected disabled >Choose...</option>
                            <option value="6">Airsoft</option>
                            <option value="7">Archery</option>                                
                            <option value="15">Pillow</option>
                            <option value="16">Bedsheet</option>
                            <option value="17">Blanket</option>
                        </select>
                    </div>
                    <div class="col-md-2 mb-1" id="divQuantity">
                        <label for="additionalServiceNumberOfPax">Quantity</label>
                        <input class="form-control paxSelect" type="number" id="additionalServiceNumberOfPax"  placeholder="" value="" min="1" max="10" >
                    </div>
                    <div class="col-md-3 mb-1" id="divUnitPrice">
                        <label for="additionalServiceUnitPrice">Unit price</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">₱</span>
                            </div>
                            <input class="form-control additionalServiceUnitPrice" type="text" id="additionalServiceUnitPrice" name="additionalServiceUnitPrice" placeholder="" value="" disabled>
                            <input class="form-control additionalServiceUnitPrice" type="text" style="display:none;float:left;" id="additionalServiceUnitPrice"  placeholder="" value="" >
                        </div>
                    </div>
                    <div class="col-md-3 mb-1" id="divTotalPrice">
                        <label for="additionalServiceTotalPrice">Total price</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">₱</span>
                            </div>
                            <input class="form-control additionalServiceTotalPrice" type="text" id="additionalServiceTotalPrice" name="additionalServiceTotalPrice" placeholder="" value="" disabled>
                            <input class="form-control additionalServiceTotalPrice" type="text" style="display:none;float:left;" id="additionalServiceTotalPrice"  placeholder="" value="" >
                        </div>
                    </div>

                    <div style="margin-top:2em;" id="divButton">
                        <div class="input-group">
                            <button type="button" id="additionalServiceFormAdd" class="btn btn-primary additionalServiceFormAdd" disabled>
                                <span class="fa fa-plus" aria-hidden="true"></span>
                            </button>
                        </div>
                    </div>
                    <input type="number" style="display:none;float:left;" id="additionalServicesCount" name="additionalServicesCount" value="0">
                </div>
                <button type="reset" id="divAdditionalServices" style="width:5em;" class="btn btn-primary divAdditionalServices">Clear</button>
                
                <div class="pt-4" style="float:right;">   
                                     
                    
                    
                    <button class="btn btn-success" id="checkinButton" style="width:10em;" type="submit">Check-in</button>
                    <a href="/glamping" style="text-decoration:none;">
                        <button class="btn btn-secondary" style="width:10em;" type="button">Cancel</button>
                    </a>
                </div>
        </div>
    </div>
<!-- charges modal -->
<div class="modal fade" id="chargesModal" tabindex="-1" role="dialog" aria-labelledby="chargesModal" aria-hidden="true">
    <div class="modal-dialog" role="document" style="width:70%">
        <div class="modal-content">
            <div id="selectedPayments" style="display:none;">
            </div>
            <div class="modal-header">
                <h5 class="modal-title">Charges</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body my-0">
                <!--form class="card my-0"-->
                    <table class="table table-striped m-0 display nowrap transactionTable" style="font-size:1em;">
                        <thead>
                            <tr>
                                <th></th>
                                <th scope="col" style="width:40%">
                                    <input class="form-check-input" type="checkbox" id="selectAll" checked>
                                    Description
                                </th>
                                <th scope="col">Qty.</th>
                                <th scope="col">Price</th>
                                <th scope="col">Total</th> 
                            </tr>
                        </thead>
                        <tbody id="chargesRows">
                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th colspan="3" scope="row">Amount due:</th>
                                <th id="chargesGrandTotal" style="text-align:right;">1500</th>
                            </tr>
                            <tr>
                            </tr>
                            <tr>
                                <th></th>
                                <th scope="row">Amount paid:</th>
                                <th style="text-align:right;"  colspan="3">
                                    <input type="number" name="amountPaid" placeholder="0" min="0" style="text-align:right;" class="form-control" id="amount">
                                </th>
                            </tr>
                        </tfoot>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="savePayments" class="btn btn-success" data-dismiss="modal">Save Changes</button>
                <!--button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button-->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>