<?php $__env->startSection('content'); ?>
<div class="container" style="position:fixed;">
    <div class="pt-3 pb-3">
        <a href="/glamping">
            <span style="float:left;">
                <i class="fa fa-chevron-left" aria-hidden="true"></i>
                <strong>Back</strong>
            </span>
        </a>
        <h3 class="text-center">Payment Transactions</h3>
    </div>
    <div class="col-md-12">
        <table data-order='[[ 1, "asc" ]]' class="table table-sm dataTable stripe compact" cellspacing="0" id="paymentsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Acc ID</th>
                    <th>Service Name</th>
                    <th>First Name</th>
                    <th>Last Name</th>                
                    <th>Payment Date</th>                            
                    <th>Payment Status</th>
                    <th>Amount Paid</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($payment->chargeID); ?></td>
                    <td><?php echo e($payment->accommodationID); ?></td>
                    <td><?php echo e($payment->serviceName); ?></td>                
                    <td><?php echo e($payment->firstName); ?></td>                             
                    <td><?php echo e($payment->lastName); ?></td>                             
                    <td><?php echo e($payment->paymentDatetime); ?></td>                                     
                    <td><?php echo e($payment->paymentStatus); ?></td>                            
                    <td><?php echo e($payment->amount); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>