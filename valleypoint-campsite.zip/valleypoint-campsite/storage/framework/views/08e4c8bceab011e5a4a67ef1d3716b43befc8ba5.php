<?php $__env->startSection('content'); ?>
<style>
    body {
        background-image: url('valleypoint.png');
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>
<div class="container col-md-5 col-sm-10 pt-5 mt-4">
    <div class="card mt-5" style="background-color: #ffffffb3;">
        <div class="mt-4 mb-3 text-center">
            <img src="<?php echo e(asset('logo.png')); ?>" style="width: 12em;">
            
        </div>
        <form method="POST" action="<?php echo e(route('login')); ?>" style="">
            <?php echo csrf_field(); ?>
            <div class="container px-5">
                <div class="form-group my-2">
                    <input id="username" type="text" placeholder="Username" maxlength="25" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username"  autocomplete = "off" value="<?php echo e(old('username')); ?>" required autofocus>
                    <?php if($errors->has('username')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                    <?php endif; ?>   
                </div>
                <div class="form-group my-2">
                    <input id="password" type="password" placeholder="Password" maxlength="25" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" autocomplete = "off" required>
                    <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary btn-block mt-4 mb-5">
                    <?php echo e(__('Login')); ?>

                </button>
                
            </div>
        </form>
   </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.logapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>