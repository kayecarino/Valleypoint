<?php $__env->startSection('content'); ?>
<div class="container pb-5">
    <div class="pt-3 pb-3">
        
        <h3 class="text-center">Guests</h3>
    </div>
    <div class="col-md-12">
        <table id="guestsTable" data-order='[[ 0, "asc" ]]' class="table table-sm dataTable stripe compact" cellspacing="0">
              <thead>
                <tr class="">
                  <th>Guest ID</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Contact Number</th>
                  <th>Accommodation</th>
                  <th>Unit Number</th>
                  <th>Number of units</th>
                  
                </tr>
              </thead>
              <tbody>
                
                <?php if(count($guest) > 1): ?>
                <?php $__currentLoopData = $guest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                  <td><?php echo e($guest->guestID); ?></td>
                  <td><?php echo e(str_limit($guest->firstName, $limit = 10, $end = '...')); ?></td>
                  <td><?php echo e(str_limit($guest->lastName, $limit = 10, $end = '...')); ?></td>
                  <td><?php echo e($guest->contactNumber); ?></td>                    
                  <td><?php echo e($guest->serviceName); ?></td>
                  
                  <td><?php echo e($guest->unitNumber); ?></td>
                  
                  <td><?php echo e($guest->numberOfUnits); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
          </table>
        </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>