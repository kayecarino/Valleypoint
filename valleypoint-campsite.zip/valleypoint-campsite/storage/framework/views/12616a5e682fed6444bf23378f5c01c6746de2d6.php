<?php $__env->startSection('content'); ?>
<div class="container pb-5">
    <div class="pt-3 pb-3">
        <h3 class="text-center">Payment Transactions</h3>
    </div>
    <div class="col-md-12">
        <table id="restaurantPaymentsTable" data-order='[[ 0, "asc" ]]' class="table table-sm dataTable stripe compact" cellspacing="0">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Table Number</th> 
                    <th>Date</th> 
                    <th>Payment Status</th>
                    <th>Amount Paid</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $restPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurantPayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($restaurantPayment->orderID); ?></td>
                    <td><?php echo e($restaurantPayment->tableNumber); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($restaurantPayment->paymentDatetime)->format('M j, Y')); ?></td>
                    <td><?php echo e($restaurantPayment->paymentStatus); ?></td> 
                    <td ><?php echo e(number_format($restaurantPayment->amount, 2)); ?></td>
                                              
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
            </tbody>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>