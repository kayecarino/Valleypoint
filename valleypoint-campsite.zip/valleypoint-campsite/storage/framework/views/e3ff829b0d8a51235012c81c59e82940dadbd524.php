<?php $__env->startSection('content'); ?>
    
    
    

    
    <div class="col-md-12 text-center lodging-tabs mx-1">
        <nav class="nav nav-pills centered-pills py-2">
            <a class="nav-item nav-link" style="color:#505050; cursor:pointer;" href="/create-order">Create Order</a>
            <a class="nav-item nav-link" style="color:#505050; cursor:pointer;" href="/view-order-slips">Order Slips</a>
            <a class="nav-item nav-link active" style="background-color:#060f0ed4;" href="#">View Tables</a>
        </nav>
    </div>
    <div class="container-fluid row col-md-12 px-5 pt-3 mx-0">
        <div class="col-md-7 scrollbar-near-moon" style="max-height:74vh; overflow-y:auto;">
            <div class="row" id="restaurantTableRow">
                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <a style="cursor:pointer">
                    <?php if($table->status == 'available'): ?> 
                    <div class="card mx-2 restaurant-available-tables" id="<?php echo e($table->id); ?>" style="width:12.5rem; height:7em; background-image:url(<?php echo e(asset('')); ?>); background-size:cover; background-repeat:no-repeat;">
                    <?php elseif($table->status == 'occupied'): ?>
                    <div class="card mx-2 restaurant-occupied-tables" id="<?php echo e($table->id); ?>" style="width:12.5rem; height:7em; background-image:url(<?php echo e(asset('')); ?>); background-size:cover; background-repeat:no-repeat;">
                    <?php endif; ?>
                        <div class="card-body">
                            <?php if($table->status == 'available'): ?> 
                            <h5 class="card-title"> 
                                <?php echo e($table->tableNumber); ?>

                                <span class="badge badge-info float-right badgeStatus" style="font-size:.55em;">Available</span>
                            </h5>
                            <?php elseif($table->status == 'occupied'): ?>
                            <h5 class="card-title"> 
                                <?php echo e($table->tableNumber); ?>

                                <span class="badge badge-dark float-right badgeStatus" style="font-size:.55em;">Occupied</span>
                            </h5>
                            <p class="card-text pt-3"> 
                                Total bill: 
                                <span class="float-right"> ₱<?php echo e(number_format($table->totalBill, 2)); ?> </span>
                            </p>
                            <?php endif; ?>
                        </div>
                    </div> 
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
        </div>
        <div class="col-md-5" id="tableOrders">
            <meta name="csrf-token" content="<?php echo e(Session::token()); ?>"> 
            <div class="mx-0 mt-2 pl-4">
                <div class="card p-0 m-0" style="min-height:70vh; max-height:70vh;">
                    <div class="row pt-2 pb-1 px-3">
                        <div class="col-md-6">
                            <div class="form-group my-1 row">
                                <label class="col-sm-5 pr-0 mr-0 pt-1" for="tableNumber">Table:</label>
                                <div class="input-group input-group-sm col-sm-4 px-0 mx-0">
                                    <input class="form-control" type="number" name="orderTableNumber" id="orderTableNumber" min="1" max="30" placeholder="" value="<?php echo e($firstTable->id); ?>" disabled>
                                    <input class="form-control" type="number" name="oldTableNumber" id="oldTableNumber" value="<?php echo e($firstTable->id); ?>" style="display:none">
                                </div>        
                                <?php if(count($items) > 0): ?>                            
                                <span id="editTableNumber" class="col-sm-2 input-group-addon hidden-elements px-3 mx-0" style="cursor:pointer">
                                    <i id="editTable" class="fa fa-pencil-alt" style="color:#3b3f44 !important;"></i>
                                </span>
                                <?php else: ?>                                
                                <span id="editTableNumber" class="col-sm-2 input-group-addon hidden-elements px-3 mx-0" style="display:none; cursor:pointer;">
                                    <i id="editTable" class="fa fa-pencil-alt" style="color:#3b3f44 !important;"></i>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if(count($items) > 0): ?>
                        <div class="hidden-elements col-md-6">
                        <?php else: ?>
                        <div class="hidden-elements col-md-6" style="display:none;">
                        <?php endif; ?>
                            <div class="form-group my-1 row">
                                <label class="col-sm-5 pr-0 mr-0 pt-1" for="queueNumber">Queue:</label>
                                <div class="input-group input-group-sm col-sm-4 px-0 mx-0">
                                <?php if(isset($orderQueueNumber)): ?>
                                    <input class="form-control" type="number" name="orderQueueNumber" id="orderQueueNumber" min="1" max="50" placeholder="" value="<?php echo e($orderQueueNumber); ?>" disabled>
                                <?php else: ?>
                                    <input class="form-control" type="number" name="orderQueueNumber" id="orderQueueNumber" min="1" max="50" placeholder="" value="" disabled>  
                                <?php endif; ?>
                                </div>                                  
                                <span id="editQueueNumber" class="col-sm-2 input-group-addon px-3 mx-0" style="cursor:pointer">
                                    <i id="editQueue" class="fa fa-pencil-alt" style="color:#3b3f44 !important;"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0 m-0 scrollbar-near-moon" style="overflow-y:auto;">
                        <table class="table table-striped mb-0" style="font-size:.88em;">
                            <thead>
                                <tr>
                                    <th scope="col" class="py-2" style="width:45%;">Description</th>
                                    <th scope="col" class="py-2">Qty.</th>
                                    <th scope="col" class="py-2">Price</th>
                                    <th scope="col" class="py-2">Total</th>
                                    <th scope="col" class="py-2">Status</th>
                                </tr>
                            </thead>
                            <tbody id="orderSlip">
                                <?php 
                                    $subTotal = 0; 
                                ?>
                                <?php if(count($items) > 0): ?>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-2"><?php echo e($item->productName); ?></td>
                                        <td class="text-right py-2"><?php echo e($item->quantity); ?></td>
                                        <?php 
                                            $subTotal += $item->totalPrice;

                                            $unitPrice = $item->totalPrice/$item->quantity;
                                        ?>
                                        <td class="text-right py-2"><?php echo e(number_format($unitPrice, 2)); ?></td>
                                        <td class="text-right py-2 orderItemPrice"><?php echo e(number_format($item->totalPrice, 2)); ?></td>
                                        <td class="py-2"><?php echo e($item->paymentStatus); ?></td>
                                    </tr>
                                    <input class="form-control" type="number" id="orderID" name="orderID" value="<?php echo e($item->orderID); ?>" style="display:none;">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td class="py-2 text-center" colspan="5"> No order items to show </td> 
                                    </tr>
                                    <input class="form-control" type="number" id="orderID" name="orderID" value="" style="display:none;">
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer bg-white border-0 px-0 mx-0">
                        <table class="table table-striped" style="font-size:.88em;">
                            <thead>
                                <tr>
                                    <th class="py-2" colspan="3" scope="row">Subtotal:</th>
                                    <td class="py-2" id="ordersSubtotal" style="text-align:right;">
                                        ₱&nbsp;<?php echo e(number_format($subTotal, 2)); ?>

                                    </td>
                                </tr>
                                <tr  class="text-primary">
                                    <th class="py-2" colspan="3" scope="row">Discount:</th>
                                    <td class="py-2" id="ordersDiscount" style="text-align:right;">
                                    <?php if(count($items) > 0): ?>
                                        ₱&nbsp;<?php echo e(number_format($item->discountAmount, 2)); ?>

                                    <?php else: ?>
                                        ₱&nbsp;0.00
                                    <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="py-2" colspan="3" scope="row">TOTAL:</th>
                                    <th class="py-2" id="ordersGrandTotal" style="text-align:right;">
                                    <?php if(count($items) > 0): ?>
                                        ₱&nbsp;<?php echo e(number_format($item->totalBill, 2)); ?>

                                    <?php else: ?>
                                        ₱&nbsp;0.00
                                    <?php endif; ?>
                                    </th>
                                </tr>
                            </thead>
                        </table>
                        <div class="row mx-1" id="orderSlipButtons">
                            <?php if(count($items) > 0): ?>
                            <div class="col-md-6 px-1">
                                <a href="/add-order/<?php echo e($items[0]->orderID); ?>" style="text-decoration:none">
                                    <button type="button" class="btn btn-primary btn-block" id="addOrder" style="text-align:center;">
                                        Add Order
                                    </button>
                                </a>
                            </div>
                            <?php else: ?>
                            <div class="col-md-6 px-1">                                
                                <a href="/create-order/" style="text-decoration:none">
                                    <button type="button" class="btn btn-primary btn-block" id="addOrder" style="text-align:center;">
                                        Add Order
                                    </button>
                                </a>
                            </div>
                            <?php endif; ?>
                            <?php if(count($items) > 0): ?>
                            <div class="col-md-6 px-1">
                                <a href="/bill-out/<?php echo e($items[0]->orderID); ?>" style="text-decoration:none">
                                    <button type="button" class="btn btn-success btn-block" id="billOut" style="text-align:center;">
                                        Bill Out
                                    </button>
                                </a>
                            </div>
                            <?php else: ?>
                            <div class="col-md-6 px-1">
                                <button type="button" class="btn btn-success btn-block" id="billOut" style="text-align:center;" disabled>
                                    Bill Out
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>