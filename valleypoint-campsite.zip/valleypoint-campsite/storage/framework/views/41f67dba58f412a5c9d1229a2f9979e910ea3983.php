<?php $__env->startSection('content'); ?>
<div class="container pb-5">
    <div class="pt-3 pb-3">
        
        <h3 class="text-center">Transaction Charges</h3>
    </div>
    <div class="col-md-12">
        <table data-order='[[ 0, "asc" ]]' class="table table-sm dataTable stripe compact" cellspacing="0" id="chargesTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Acc ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>   
                    <th>Service Name</th>             
                    <th>Quantity</th>                            
                    <th>Price</th>
                    <th>Balance</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($charge->chargeID); ?></td>
                    <td><?php echo e($charge->accommodationID); ?></td>             
                    <td><?php echo e($charge->firstName); ?></td>                              
                    <td><?php echo e($charge->lastName); ?></td>    
                    <td><?php echo e($charge->serviceName); ?></td>                           
                    <td class="text-right"><?php echo e($charge->quantity); ?></td>                                     
                    <td class="text-right"><?php echo e(number_format((float)($charge->totalPrice), 2, '.', '')); ?></td>                            
                    <td class="text-right"><?php echo e(number_format((float)($charge->balance), 2, '.', '')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>