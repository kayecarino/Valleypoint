<?php $__env->startSection('content'); ?>
    <div class="container pb-5">
        <div class="py-3 text-center">
            <a href="<?php echo e(URL::previous()); ?>">
                <span style="float:left;">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>
                    <strong>Back</strong>
                </span>
            </a>
            <h3> Transactions </h3>
        </div>
        <div class="row">
            <div class="container col-md-7">
                <div class="card mx-0 scrollbar-near-moon px-2 py-3" style="max-height:70vh; overflow-y:auto;">
                    <h5 style="text-align:center; padding-top:0.5em;">Charges</h5>
                    <table data-order='[[ 0, "asc" ]]' class="table table table-hover table-sm dataTable compact" cellspacing="0">
                        <thead>
                            <tr>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">No.</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Guest Name</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Service</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Price</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Balance</th>
                                
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Unit</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="guestChargesRows" id="<?php echo e($charge->chargeID); ?>">
                                <th scope="row"><?php echo e($charge->chargeID); ?></th>
                                <td scope="row"><?php echo e($charge->firstName); ?> <?php echo e($charge->lastName); ?></td>
                                <td scope="row"><?php echo e($charge->serviceName); ?></td>
                                <td scope="row" class="text-right"><?php echo e(number_format((float)($charge->totalPrice), 2, '.', '')); ?></td>
                                <td scope="row" class="text-right"><?php echo e(number_format((float)($charge->balance), 2, '.', '')); ?></td>
                                
                                <td scope="row"><?php echo e($charge->unitNumber); ?></td>
                                
                            </tr>                        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
    
            <div class="container col-md-5">
                <div class="card mx-0 scrollbar-near-moon px-2 py-3" style="max-height:67vh; overflow-y:auto;">
                    <h5 style="text-align:center; padding-top:0.5em; ">Payments</h5>
                    <table class="table table-hover table-sm">
                        <thead>
                            <tr>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">No.</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Amount</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Remarks</th>
                                <th scope="col" style="background-color:rgb(233, 236, 239);">Date and Time</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($payment->chargeID); ?> guestPaymentsRows">
                                <th scope="row"><?php echo e($payment->paymentID); ?></th>
                                <td style="text-align:right"><?php echo e(number_format((float)($payment->amount), 2, '.', '')); ?></td>
                                <td><?php echo e($payment->paymentStatus); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($payment->paymentDatetime)->format('F j, Y h:iA')); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>