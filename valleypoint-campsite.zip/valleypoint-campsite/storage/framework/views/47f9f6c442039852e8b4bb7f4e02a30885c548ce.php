<?php $__env->startSection('content'); ?>
<?php if(count($unit) > 0): ?>
    <?php if(count($reservation) > 0): ?>
    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container pb-5">
        <div class="pt-3 pb-3 text-center">
            <a href="/glamping">
                <span style="float:left;">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>
                    <strong>Back</strong>
                </span>
            </a>
            <h3>Check-in Form</h3>
        </div>   
        <form method="POST" action="/checkin-glamping-reservation">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="selectedUnit" id="selectedUnit" value="<?php echo e($unit->unitNumber); ?>">
        <input type="hidden" name="reservationID" id="reservationID" value="<?php echo e($reservation->id); ?>">
        <div class="row">
            <div class="col-md-4 order-md-2 mb-4 mx-0">
                <div class="card p-0 mx-0">
                    <h4 class="text-muted" style="text-align:center; padding:0.5em;">Charges</h4>
                    <table class="table table-striped" style="font-size:.88em;">
                        <thead>
                            <tr>
                                <th scope="col" style="width:40%">Description</th>
                                <th scope="col">Qty.</th>
                                <th scope="col">Price</th>
                                <th scope="col">Total</th>
                            </tr>
                        </thead>
                        <tbody id="invoiceRows">
                            <?php
                                $totalPrice = 0;    
                            ?>
                            <?php if(count($charges) > 0): ?>
                            <?php $__currentLoopData = $charges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $charge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $checkin = new DateTime(/*$charge->checkinDatetime*/\Carbon\Carbon::now()->addDays(1));
                                $checkout = new DateTime($charge->checkoutDatetime);
                                $stayDuration = date_diff($checkin, $checkout)->days+1;
                            ?>
                            <tr id="invoiceUnit<?php echo e($charge->unitNumber); ?>">
                                <td style="display:none;"><input id="invoiceCheckBox<?php echo e($charge->unitNumber); ?>" class="form-check-input invoiceCheckboxes" type="checkbox" checked>
                                <input type="hidden" name="charge<?php echo e($charge->unitNumber); ?>" class="chargeIDs" value="<?php echo e($charge->chargeID); ?>"></td>
                                <td id="invoiceDescription<?php echo e($charge->unitNumber); ?>" class="invoiceDescriptions"><?php echo e($charge->serviceName); ?></td>
                                <td id="invoiceQuantity<?php echo e($charge->unitNumber); ?>" style="text-align:right;" class="invoiceQuantities"><?php echo e($charge->quantity); ?>x<?php echo e($stayDuration); ?></td>
                                <td id="invoiceUnitPrice<?php echo e($charge->unitNumber); ?>" style="text-align:right;" class="invoiceUnitPrices"><?php echo e($charge->price); ?></td>
                                <td id="invoiceTotalPrice<?php echo e($charge->unitNumber); ?>" style="text-align:right;" class="invoicePrices"><?php echo e($charge->totalPrice); ?></td>
                            </tr>
                            <?php
                                $totalPrice += $charge->totalPrice;    
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php if(count($additionalServices) > 0): ?>
                            <?php $__currentLoopData = $additionalServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additionalService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="invoiceRow<?php echo e($loop->iteration); ?>">
                            <td style="display:none;"><input id="invoiceCheckBox<?php echo e($loop->iteration); ?>" class="form-check-input invoiceCheckboxes" type="checkbox" checked>
                            <input type="hidden" name="charge<?php echo e($loop->iteration); ?>" class="chargeIDs" value="<?php echo e($additionalService->chargeID); ?>"></td>
                            <td id="invoiceDescription<?php echo e($loop->iteration); ?>" class="invoiceDescriptions"><?php echo e($additionalService->serviceName); ?></td>
                            <td id="invoiceQuantity<?php echo e($loop->iteration); ?>" style="text-align:right;" class="invoiceQuantities"><?php echo e($additionalService->quantity); ?></td>
                            <td id="invoiceUnitPrice<?php echo e($loop->iteration); ?>" style="text-align:right;" class="invoiceUnitPrices"><?php echo e($additionalService->price); ?></td>
                            <td id="invoiceTotalPrice<?php echo e($loop->iteration); ?>" style="text-align:right;" class="invoicePrices"><?php echo e($additionalService->totalPrice); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="3" scope="row">TOTAL:</th>
                                <th id="invoiceGrandTotal" style="text-align:right;"><?php echo e($totalPrice); ?></th>
                            </tr>
                            <tr>
                                <td colspan="4"><button type="button" class="btn btn-primary btn-block w-100" style="text-align:center;width:8em" id="proceedToPayment" data-toggle="modal" data-target="#chargesModal">
                                    Get payment
                                </button></td>
                            </tr>
                            
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="col-md-8 order-md-1 check-in-form">
                <h5 style="margin-bottom:.80em;">Guest Details</h5>
                    <div class="form-group row">
                        <div class="col-md-4 mb-1">
                            <label for="firstName">First name</label>
                            <input class="form-control" type="text" name="firstName" required="required" maxlength="15" placeholder="" value="<?php echo e($reservation->firstName); ?>">
                        </div>
                        <div class="col-md-5 mb-1">
                            <label for="lastName">Last name</label>
                            <input class="form-control" type="text" name="lastName" required="required" maxlength="20" placeholder="" value="<?php echo e($reservation->lastName); ?>">
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="unitNumberOfPax">No. of pax</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-users" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input class="form-control numberOfPaxGlamping"  required="required" min="1" max="100" name="numberOfPaxGlamping" type="number" placeholder="" value="<?php echo e($reservation->numberOfPax); ?>">
                            </div>
                        </div>
                    </div>  
                    <div class="form-group row">
                        <div class="col-md-6 mb-1">
                            <label for="contactNumber">Contact number</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input class="form-control" type="text" name="contactNumber"  required="required" maxlength="11" placeholder="" value="<?php echo e($reservation->contactNumber); ?>">
                            </div>
                        </div>
                        <div class="col-md-6 mb-1">
                            <label for="glamping">Accommodation</label>
                            <div class="input-group">
                                <input class="form-control" type="text" name="glamping" maxlength="11" placeholder="" value="Glamping" disabled>
                            </div>
                        </div>
                    </div>  
                    <hr class="mb-4">
                    <h5 style="margin-bottom:.80em;">Unit Details</h5>
                    <div class="form-group row">
                        <div class="col-md-2 mb-1">
                            <label for="unitID">No. of tents</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fa fa-campground" aria-hidden="true"></i>
                                    </span>
                                </div>
                            <input class="form-control" type="number" id="numberOfUnits" name="numberOfUnits" required placeholder="" value="<?php echo e($reservation->numberOfUnits); ?>" min="1" max="80" readonly>
                            </div>
                        </div>
                        <?php
                            //$source = implode(',', array($unitSource->unitNumber));
                            $source = array();
                            foreach($unitSource as $unitSource) {
                                array_push($source, $unitSource->unitNumber);
                            }

                            $source = implode(',', $source);
                        ?>
                        
                        <?php if(count($allReservedUnits) > 0): ?>
                        <?php
                            $units = "";
                        ?>
                        <?php $__currentLoopData = $allReservedUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleReservedUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if($loop->iteration == count($allReservedUnits)){
                                $units .= $singleReservedUnit->unitNumber." ";
                            } else {
                                $units .= $singleReservedUnit->unitNumber.", ";
                            }
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="col-md-10 mb-1">
                            <label for="unitNumber">Unit/s</label>
                            <input type="text" name="unitID" required="required" class="form-control" style="display:none;position:absolute;" value="<?php echo e($unit->id); ?>">
                            <input class="form-control" type="text" name="unitNumber" required id="tokenfield" value="<?php echo e($units); ?>" required>
                            <input type="hidden" id="unitSource" value="<?php echo e($source); ?>">
                            <input class="form-control" style="display:none;float:left;" type="text" name="unitID" value="<?php echo e($unit->id); ?>">
                        </div>
                    </div>
                    <?php if(count($reservedUnit) > 0): ?>
                    <?php $__currentLoopData = $reservedUnit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservedUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php                        
                        $checkin = new DateTime($reservedUnit->checkinDatetime);
                        $checkout = new DateTime($reservedUnit->checkoutDatetime);
                        $stayDuration = date_diff($checkin, $checkout)->days+1;

                        $unitTotalPrice = $reservedUnit->price * $reservedUnit->numberOfPax * $stayDuration;
                    ?>
                    <div class="form-group row" id="divUnits">
                        <div class="col-md-2 mb-1" id="divUnitNumber<?php echo e($reservedUnit->unitNumber); ?>">
                            <label for="unitNumber">Unit number</label>
                            <input type="text" class="form-control" value="<?php echo e($reservedUnit->unitNumber); ?>" disabled>
                            <input class="" name="totalPrice<?php echo e($reservedUnit->unitNumber); ?>" id="totalPrice<?php echo e($reservedUnit->unitNumber); ?>" type="number" style="display:none;position:absolute" value="<?php echo e($unitTotalPrice); ?>">
                        </div>
                        <div class="col-md-2 mb-1" id="divAccommodationPackage<?php echo e($reservedUnit->unitNumber); ?>">
                            <label for="additionalServiceUnitPrice">Package</label>
                            <select class="form-control accommodationPackages" name="accommodationPackage<?php echo e($reservedUnit->unitNumber); ?>" value="<?php echo e($reservedUnit->serviceID); ?>" id="accommodationPackage<?php echo e($reservedUnit->unitNumber); ?>">
                                <?php if($reservedUnit->serviceID == 1): ?>                                
                                <option value="1" selected>Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4">4 pax</option>

                                <?php elseif($reservedUnit->serviceID == 2): ?>                                
                                <option value="1">Solo</option>
                                <option value="2" selected>2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4">4 pax</option>
                                
                                <?php elseif($reservedUnit->serviceID == 3): ?>
                                <option value="1">Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3" selected>3 pax</option>
                                <option value="4">4 pax</option>
                                
                                <?php elseif($reservedUnit->serviceID == 4): ?>
                                <option value="1">Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4" selected>4 pax</option>

                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="col-md-4 mb-1" id="divCheckinDate<?php echo e($reservedUnit->unitNumber); ?>">
                            <label for="checkinDate">Check-in date</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                            <input type="date" name="checkinDate<?php echo e($reservedUnit->unitNumber); ?>" required="required" class="form-control checkinDates" id="checkinDate<?php echo e($reservedUnit->unitNumber); ?>" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                            </div>
                        </div>

                        <div class="col-md-4 mb-1" id="divCheckoutDate<?php echo e($reservedUnit->unitNumber); ?>">
                            <label for="checkoutDate">Check-out date</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input type="date" name="checkoutDate<?php echo e($reservedUnit->unitNumber); ?>" required="required" class="form-control checkoutDates" id="checkoutDate<?php echo e($reservedUnit->unitNumber); ?>" value="<?php echo e(\Carbon\Carbon::parse($reservedUnit->checkoutDatetime)->format('Y-m-d')); ?>">
                                
                            </div>
                        </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                    <?php if(count($otherReservedUnits) > 0): ?>
                    <?php $__currentLoopData = $otherReservedUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherReservedUnits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $unitTotalPrice = $otherReservedUnits->price * $otherReservedUnits->numberOfPax;
                    ?>
                        <div class="col-md-2 mb-1" id="divUnitNumber<?php echo e($otherReservedUnits->unitNumber); ?>">
                            
                            <input type="text" class="form-control" value="<?php echo e($otherReservedUnits->unitNumber); ?>" disabled>
                        <input class="" name="totalPrice<?php echo e($otherReservedUnits->unitNumber); ?>" id="totalPrice<?php echo e($otherReservedUnits->unitNumber); ?>" type="number" style="display:none;position:absolute" value="<?php echo e($unitTotalPrice); ?>">
                        </div>
                        <div class="col-md-2 mb-1" id="divAccommodationPackage<?php echo e($otherReservedUnits->unitNumber); ?>">
                            
                            <select class="form-control accommodationPackages" name="accommodationPackage<?php echo e($otherReservedUnits->unitNumber); ?>" value="<?php echo e($otherReservedUnits->serviceID); ?>" id="accommodationPackage<?php echo e($otherReservedUnits->unitNumber); ?>">
                                <?php if($otherReservedUnits->serviceID == 1): ?>                                
                                <option value="1" selected>Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4">4 pax</option>

                                <?php elseif($otherReservedUnits->serviceID == 2): ?>                                
                                <option value="1">Solo</option>
                                <option value="2" selected>2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4">4 pax</option>
                                
                                <?php elseif($otherReservedUnits->serviceID == 3): ?>
                                <option value="1">Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3" selected>3 pax</option>   
                                <option value="4">4 pax</option>
                                
                                <?php elseif($otherReservedUnits->serviceID == 4): ?>
                                <option value="1">Solo</option>
                                <option value="2">2 Pax</option>
                                <option value="3">3 pax</option>
                                <option value="4" selected>4 pax</option>

                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="col-md-4 mb-1" id="divCheckinDate<?php echo e($otherReservedUnits->unitNumber); ?>">
                            
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                            <input type="date" name="checkinDate<?php echo e($otherReservedUnits->unitNumber); ?>" required="required" class="form-control checkinDates" id="checkinDate<?php echo e($otherReservedUnits->unitNumber); ?>" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                            </div>
                        </div>

                        <div class="col-md-4 mb-1" id="divCheckoutDate<?php echo e($otherReservedUnits->unitNumber); ?>">
                            
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="far fa-calendar-alt" aria-hidden="true"></i>
                                    </span>
                                </div>
                                <input type="date" name="checkoutDate<?php echo e($otherReservedUnits->unitNumber); ?>" required="required" class="form-control checkoutDates" id="checkoutDate<?php echo e($otherReservedUnits->unitNumber); ?>" value="<?php echo e(\Carbon\Carbon::parse($otherReservedUnits->checkoutDatetime)->format('Y-m-d')); ?>">
                                
                            </div>
                        </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    
                    </div>

                    <div id="dateGapContainer" class="alert alert-warning mt-2" style="display:none;">
                        <a href="#" class="close">&times;</a>
                        <span id="dateGapMessage"><strong>Invalid Dates!</strong> Accommodation dates must be consecutive.</span>
                    </div>

                    <div id="dateAlertContainer" class="alert alert-warning mt-2" style="display:none;">
                        <a href="#" class="close">&times;</a>
                        <span id="dateAlertMessage"><strong>Invalid Date!</strong> Please select a check-out date after the check-in date.</span>
                    </div>

                    <div id="alertContainer" class="alert alert-danger mt-2" style="display:none;">
                        <a href="#" class="close">&times;</a>
                        <span id="alertMessage"><strong>Occupied!</strong> Tent 3 is occupied from March 25 to March 27.</span>
                    </div>
                    
                    <hr class="mb-4">
                    <div class="form-group row pb-3" id="divAdditionalServices">
                        <div class="col-md-12 mb-1">
                            <h5 style="margin-bottom:.80em;">Additional Services</h5>
                        </div>
                        <input type="hidden" >
                        <div class="col-md-3 mb-1" id="divServiceName">
                            <label for="additionalServiceName">Service name</label>
                            <select name="additionalServiceName" id="serviceSelect" class="form-control serviceSelect" >
                                <option value="choose" selected disabled >Choose...</option>
                                <option value="6">Airsoft</option>
                                <option value="7">Archery</option>                                
                                <option value="15">Pillow</option>
                                <option value="16">Bedsheet</option>
                                <option value="17">Blanket</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-1" id="divQuantity">
                            <label for="additionalServiceNumberOfPax">Quantity</label>
                            <input class="form-control paxSelect" type="number" id="additionalServiceNumberOfPax"  placeholder="" value="" min="1" max="10" >
                        </div>
                        <div class="col-md-3 mb-1" id="divUnitPrice">
                            <label for="additionalServiceUnitPrice">Unit price</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">₱</span>
                                </div>
                                <input class="form-control additionalServiceUnitPrice" type="text" id="additionalServiceUnitPrice" name="additionalServiceUnitPrice" placeholder="" value="" disabled>
                                <input class="form-control additionalServiceUnitPrice" type="text" style="display:none;float:left;" id="additionalServiceUnitPrice"  placeholder="" value="" >
                            </div>
                        </div>
                        <div class="col-md-3 mb-1" id="divTotalPrice">
                            <label for="additionalServiceTotalPrice">Total price</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">₱</span>
                                </div>
                                <input class="form-control additionalServiceTotalPrice" type="text" id="additionalServiceTotalPrice" name="additionalServiceTotalPrice" placeholder="" value="" disabled>
                                <input class="form-control additionalServiceTotalPrice" type="text" style="display:none;float:left;" id="additionalServiceTotalPrice"  placeholder="" value="" >
                            </div>
                        </div>

                        <div style="margin-top:2em;" id="divButton">
                            <div class="input-group">
                                <button type="button" id="additionalServiceFormAdd" class="btn btn-primary additionalServiceFormAdd" disabled>
                                    <span class="fa fa-plus" aria-hidden="true"></span>
                                </button>
                            </div>
                        </div>
                    <input type="number" style="display:none;float:left;" id="additionalServicesCount" name="additionalServicesCount" value="<?php echo e(count($additionalCharges)); ?>">

                        <?php if(count($additionalCharges) > 0): ?>
                        <?php $__currentLoopData = $additionalCharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additionalCharge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type='text' style='display:none;float:left;' id='additionalServiceID<?php echo e($loop->iteration); ?>' name='additionalServiceID<?php echo e($loop->iteration); ?>' value='<?php echo e($additionalCharge->id); ?>'>
                        <div class='col-md-3 mb-1' id='divServiceName<?php echo e($loop->iteration); ?>'>
                            <input class='form-control paxSelect' type='text' name='additionalServiceName<?php echo e($loop->iteration); ?>' value='<?php echo e($additionalCharge->serviceName); ?>' readonly>
                        </div>
                        <div class='col-md-2 mb-1' id='divQuantity<?php echo e($loop->iteration); ?>'>
                            <input class='form-control paxSelect' type='number' id='additionalServiceNumberOfPax' name='additionalServiceNumberOfPax<?php echo e($loop->iteration); ?>' value='<?php echo e($additionalCharge->quantity); ?>' min='1' max='10'  readonly>
                        </div>
                        <div class='col-md-3 mb-1' id='divUnitPrice<?php echo e($loop->iteration); ?>'>
                            <div class='input-group'>
                                <div class='input-group-prepend'>
                                    <span class='input-group-text'>₱</span>
                                </div>
                            <input class='form-control additionalServiceUnitPrice' type='text' id='additionalServiceUnitPrice' name='additionalServiceUnitPrice<?php echo e($loop->iteration); ?>' placeholder='' value='<?php echo e($additionalCharge->price); ?>' readonly>
                            </div>
                        </div>
                        <div class='col-md-3 mb-1' id='divTotalPrice<?php echo e($loop->iteration); ?>'>
                            <div class='input-group'>
                                <div class='input-group-prepend'>
                                    <span class='input-group-text'>₱</span>
                                </div>
                            <input class='form-control additionalServiceTotalPrice' type='text' id='additionalServiceTotalPrice' name='additionalServiceTotalPrice<?php echo e($loop->iteration); ?>' placeholder='' value='<?php echo e($additionalCharge->totalPrice); ?>' readonly>
                            </div>
                        </div>
                        <div id='divButton<?php echo e($loop->iteration); ?>'>
                            <div class='input-group'>
                                <button type='button' id='additionalServiceFormRemove<?php echo e($loop->iteration); ?>' value='<?php echo e($loop->iteration); ?>' class='btn btn-danger additionalServiceFormRemove'>
                                    <span class='fa fa-minus' aria-hidden='true'></span>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    
                    <div class="pt-4" style="float:right;">   
                                         
                        
                        
                        <button class="btn btn-success" id="checkinButton" style="width:10em;" type="submit">Check-in</button>
                        <a href="/glamping" style="text-decoration:none;">
                            <button class="btn btn-secondary" style="width:10em;" type="button">Cancel</button>
                        </a>
                    </div>
            </div>
        </div>
    <!-- charges modal -->
    <div class="modal fade" id="chargesModal" tabindex="-1" role="dialog" aria-labelledby="chargesModal" aria-hidden="true">
        <div class="modal-dialog" role="document" style="width:70%">
            <div class="modal-content">
                <div id="selectedPayments" style="display:none;">
                </div>
                <div class="modal-header">
                    <h5 class="modal-title">Charges</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body my-0">
                    <!--form class="card my-0"-->
                        <table class="table table-striped m-0 display nowrap transactionTable" style="font-size:1em;">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th scope="col" style="width:40%">
                                        <input class="form-check-input" type="checkbox" id="selectAll" checked>
                                        Description
                                    </th>
                                    <th scope="col">Qty.</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Total</th> 
                                </tr>
                            </thead>
                            <tbody id="chargesRows">
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th></th>
                                    <th colspan="3" scope="row">Amount due:</th>
                                    <th id="chargesGrandTotal" style="text-align:right;">1500</th>
                                </tr>
                                <tr>
                                </tr>
                                <tr>
                                    <th></th>
                                    <th scope="row">Amount paid:</th>
                                    <th style="text-align:right;"  colspan="3">
                                        <input type="number" name="amountPaid" placeholder="0" min="0" style="text-align:right;" class="form-control" id="amount">
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" id="savePayments" class="btn btn-success" data-dismiss="modal">Save Changes</button>
                    <!--button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button-->
                </div>
            </div>
        </div>
    </div>
    <!-- end of charges modal -->                     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>