<?php $__env->startSection('content'); ?>
    <div class="container row pb-5 pt-3">
        <div class="col-md-2 float-right mx-5 pl-4" style="position:fixed; right:0;">
            <nav class="nav nav-pills nav-stacked mb-5 pb-5" style="display:block;">
                <a class="nav-item nav-link reports-tabs text-center active" style="background-color:#060f0ed4;" href="#">Daily</a>
                <a class="nav-item nav-link reports-tabs text-center" style="color:#505050" href="/this-weeks-restaurant-report">Weekly</a>
                <a class="nav-item nav-link reports-tabs text-center" style="color:#505050" href="/this-months-restaurant-report">Monthly</a>
                <a class="nav-item nav-link reports-tabs text-center" style="color:#505050" href="/custom-restaurant-report">Custom</a>
            </nav>
            <form method="POST" action="/reload-daily-restaurant-report">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                <div class="row px-3">
                    <div class="form-group col-md-9 px-0 mx-1">
                        <div class="input-group input-group-sm">
                            <input class="form-control restaurantReportDateInputs" id="restaurantReportDate" type="date" name="restaurantReportDate" value="<?php echo date("Y-m-d");?>" required>
                        </div>
                    </div>
                    <div class="col-md-2 px-0 mx-1">
                        <button class="btn btn-sm btn-success" type="submit">
                            <i class="fa fa-calendar-check" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="container col-md-10 col-sm-12">
            <div class="card col-md-10 offset-md-1 col-sm-12 py-4 ">
                <div class="row">
                    <div class="col-md-6 col-sm-4">
                        <img src=<?php echo e(asset('logo.png')); ?> class="float-left" style="height:7.5em; width:9.75em;" aria-hidden="true"></img>
                    </div>
                    <div class="col-md-6 col-sm-8 px-5 pt-3">
                        <h6 class="text-right"> Restaurant Sales Report </h6>
                        <?php if(isset($display)): ?>
                        <h6 class="text-right"> <?php echo e(\Carbon\Carbon::parse($display)->format('F j, o')); ?> </h6>
                        <?php else: ?>
                        <h6 class="text-right"> <?php echo e(\Carbon\Carbon::now()->format('F j, o')); ?></h6>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                <div class="row">
                <div class="col-md-12">
                            <table class="table table-sm table-bordered" style="font-size:.90em;">
                                <tr>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                                <th>Order Date</th>
                                <tbody>
                                    <?php if(count($productOrdered) > 1): ?>
                                    <?php
                                    
                                    $totalPrice = 0;
                                ?>
                                    <?php $__currentLoopData = $productOrdered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="">
                                      <td><?php echo e($orders->productName); ?></td>
                                      <td><?php echo e($orders->productCategory); ?></td>
                                      <td class="text-right"><?php echo e($orders->quantity); ?></td>
                                      <td class="restaurantPricesDaily text-right"><?php echo e($orders->totalPrice); ?></td>
                                      <td class="text-right"><?php echo e(\Carbon\Carbon::parse($orders->orderDatetime)->format('M j, Y')); ?></td>
                                    </tr>

                                    <?php
                                        $totalPrice += $orders->totalPrice;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                        </table>
                              <div class="form-group row py-0 my-0 ">
                              <h6 label for="totalIncome" class="col-sm-4 pt-2" id="restaurantIncomeDaily" style="font-size:1em; margin-left:30em; margin-bottom:2em;">Gross Sales: ₱<?php echo e(number_format($totalPrice, 2)); ?></label></h6>
                                     <!-- <input class="form-control-plaintext col-sm-8"  type="number" name="totalIncome" value="0000.00"> -->
                                    
                                    <?php endif; ?>                            
                             </div>
                     </div> 
                </div>
            </div>
        </div> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>