<?php $__env->startSection('content'); ?>
<div class="container pb-5">
    <div class="pt-3 pb-3">
        
        <h3 class="text-center">Reservations</h3>
    </div>
    <div class="col-md-12">
        <table data-order='[[ 0, "asc" ]]' class="table table-sm dataTable stripe compact" cellspacing="0" id="reservationTable">
            <thead>
                <tr>
                    <!--th scope="col">Type</th-->                    
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact No.</th>
                    <th>Unit No.</th>
                    <th>Check-in Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if(count($reservations) > 0): ?>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                                
                <td><?php echo e($reservation->reservationID); ?></td>
                <td><?php echo e($reservation->firstName); ?></td>
                <td><?php echo e($reservation->lastName); ?></td>
                <td><?php echo e($reservation->contactNumber); ?></td>
                <td><?php echo e($reservation->unitNumber); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($reservation->checkinDatetime)->format('M j, Y')); ?></td>
                <td><a href="/checkin/<?php echo e($reservation->unitID); ?>/<?php echo e($reservation->id); ?>"><button class="btn btn-sm btn-success">Check-in</button></a>
                        <button class="btn btn-sm btn-info">Edit</button>
                    <a id="<?php echo e($reservation->reservationID); ?>-<?php echo e($reservation->unitID); ?>" class="cancel-reservation-modal" data-toggle="modal" data-target="#removeReservationModal">
                        <button class="btn btn-sm btn-danger">Cancel</button>
                    </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Cancel reservation modal -->
<div class="modal fade" id="removeReservationModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-full-height modal-right modal-notify modal-info" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cancel Reservation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="cancelReservationModalBody">
                
            </div>
            <div class="modal-footer">
                <a href="" id="confirmCancel"><button type="button" class="btn btn-danger" style="width:5em;">Yes</button></a>
                <button type="button" class="btn btn-primary" style="width:5em;" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>