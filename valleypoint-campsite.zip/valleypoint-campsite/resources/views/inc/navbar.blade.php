@extends('layouts.app')

@section('content')
  <h1>View Guests</h1>
  <p>This is the view guests module.</p>
@endsection